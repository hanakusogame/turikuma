(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.aez_bundle_main = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";
var ActionType;
(function (ActionType) {
    ActionType[ActionType["Wait"] = 0] = "Wait";
    ActionType[ActionType["Call"] = 1] = "Call";
    ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
    ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
    ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
    ActionType[ActionType["Cue"] = 5] = "Cue";
    ActionType[ActionType["Every"] = 6] = "Every";
})(ActionType || (ActionType = {}));
module.exports = ActionType;

},{}],2:[function(require,module,exports){
"use strict";
/**
 * Easing関数群。
 * 参考: http://gizma.com/easing/
 */
var Easing;
(function (Easing) {
    /**
     * 入力値をlinearした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function linear(t, b, c, d) {
        return c * t / d + b;
    }
    Easing.linear = linear;
    /**
     * 入力値をeaseInQuadした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInQuad(t, b, c, d) {
        t /= d;
        return c * t * t + b;
    }
    Easing.easeInQuad = easeInQuad;
    /**
     * 入力値をeaseOutQuadした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutQuad(t, b, c, d) {
        t /= d;
        return -c * t * (t - 2) + b;
    }
    Easing.easeOutQuad = easeOutQuad;
    /**
     * 入力値をeaseInOutQuadした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutQuad(t, b, c, d) {
        t /= d / 2;
        if (t < 1)
            return c / 2 * t * t + b;
        --t;
        return -c / 2 * (t * (t - 2) - 1) + b;
    }
    Easing.easeInOutQuad = easeInOutQuad;
    /**
     * 入力値をeaseInQubicした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInCubic(t, b, c, d) {
        t /= d;
        return c * t * t * t + b;
    }
    Easing.easeInCubic = easeInCubic;
    /**
     * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
     */
    Easing.easeInQubic = easeInCubic;
    /**
     * 入力値をeaseOutQubicした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutCubic(t, b, c, d) {
        t /= d;
        --t;
        return c * (t * t * t + 1) + b;
    }
    Easing.easeOutCubic = easeOutCubic;
    /**
     * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
     */
    Easing.easeOutQubic = easeOutCubic;
    /**
     * 入力値をeaseInOutQubicした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutCubic(t, b, c, d) {
        t /= d / 2;
        if (t < 1)
            return c / 2 * t * t * t + b;
        t -= 2;
        return c / 2 * (t * t * t + 2) + b;
    }
    Easing.easeInOutCubic = easeInOutCubic;
    /**
     * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
     */
    Easing.easeInOutQubic = easeInOutCubic;
    /**
     * 入力値をeaseInQuartした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInQuart(t, b, c, d) {
        t /= d;
        return c * t * t * t * t + b;
    }
    Easing.easeInQuart = easeInQuart;
    /**
     * 入力値をeaseOutQuartした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutQuart(t, b, c, d) {
        t /= d;
        --t;
        return -c * (t * t * t * t - 1) + b;
    }
    Easing.easeOutQuart = easeOutQuart;
    /**
     * 入力値をeaseInQuintした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInQuint(t, b, c, d) {
        t /= d;
        return c * t * t * t * t * t + b;
    }
    Easing.easeInQuint = easeInQuint;
    /**
     * 入力値をeaseOutQuintした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutQuint(t, b, c, d) {
        t /= d;
        --t;
        return c * (t * t * t * t * t + 1) + b;
    }
    Easing.easeOutQuint = easeOutQuint;
    /**
     * 入力値をeaseInOutQuintした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutQuint(t, b, c, d) {
        t /= d / 2;
        if (t < 1)
            return c / 2 * t * t * t * t * t + b;
        t -= 2;
        return c / 2 * (t * t * t * t * t + 2) + b;
    }
    Easing.easeInOutQuint = easeInOutQuint;
    /**
     * 入力値をeaseInSineした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInSine(t, b, c, d) {
        return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
    }
    Easing.easeInSine = easeInSine;
    /**
     * 入力値をeaseOutSineした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutSine(t, b, c, d) {
        return c * Math.sin(t / d * (Math.PI / 2)) + b;
    }
    Easing.easeOutSine = easeOutSine;
    /**
     * 入力値をeaseInOutSineした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutSine(t, b, c, d) {
        return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
    }
    Easing.easeInOutSine = easeInOutSine;
    /**
     * 入力値をeaseInExpoした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInExpo(t, b, c, d) {
        return c * Math.pow(2, 10 * (t / d - 1)) + b;
    }
    Easing.easeInExpo = easeInExpo;
    /**
     * 入力値をeaseInOutExpoした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutExpo(t, b, c, d) {
        t /= d / 2;
        if (t < 1)
            return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
        --t;
        return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
    }
    Easing.easeInOutExpo = easeInOutExpo;
    /**
     * 入力値をeaseInCircした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInCirc(t, b, c, d) {
        t /= d;
        return -c * (Math.sqrt(1 - t * t) - 1) + b;
    }
    Easing.easeInCirc = easeInCirc;
    /**
     * 入力値をeaseOutCircした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeOutCirc(t, b, c, d) {
        t /= d;
        --t;
        return c * Math.sqrt(1 - t * t) + b;
    }
    Easing.easeOutCirc = easeOutCirc;
    /**
     * 入力値をeaseInOutCircした結果の現在位置を返す。
     * @param t 経過時間
     * @param b 開始位置
     * @param c 終了位置
     * @param d 所要時間
     */
    function easeInOutCirc(t, b, c, d) {
        t /= d / 2;
        if (t < 1)
            return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
        t -= 2;
        return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
    }
    Easing.easeInOutCirc = easeInOutCirc;
})(Easing || (Easing = {}));
module.exports = Easing;

},{}],3:[function(require,module,exports){
"use strict";
var Tween = require("./Tween");
/**
 * タイムライン機能を提供するクラス。
 */
var Timeline = /** @class */ (function () {
    /**
     * Timelineを生成する。
     * @param scene タイムラインを実行する `Scene`
     */
    function Timeline(scene) {
        this._scene = scene;
        this._tweens = [];
        this._fps = this._scene.game.fps;
        this.paused = false;
        scene.update.add(this._handler, this);
    }
    /**
     * Timelineに紐付いたTweenを生成する。
     * @param target タイムライン処理の対象にするオブジェクト
     * @param option Tweenの生成オプション
     */
    Timeline.prototype.create = function (target, option) {
        var t = new Tween(target, option);
        this._tweens.push(t);
        return t;
    };
    /**
     * Timelineに紐付いたTweenを削除する。
     * @param tween 削除するTween。
     */
    Timeline.prototype.remove = function (tween) {
        var index = this._tweens.indexOf(tween);
        if (index < 0) {
            return;
        }
        this._tweens.splice(index, 1);
    };
    /**
     * Timelineに紐付いた全Tweenの紐付けを解除する。
     */
    Timeline.prototype.clear = function () {
        this._tweens.length = 0;
    };
    /**
     * このTimelineを破棄する。
     */
    Timeline.prototype.destroy = function () {
        this._tweens.length = 0;
        if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
        }
        this._scene = undefined;
    };
    /**
     * このTimelineが破棄済みであるかを返す。
     */
    Timeline.prototype.destroyed = function () {
        return this._scene === undefined;
    };
    Timeline.prototype._handler = function () {
        if (this._tweens.length === 0 || this.paused) {
            return;
        }
        var tmp = [];
        for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];
            if (!tween.destroyed()) {
                tween._fire(1000 / this._fps);
                tmp.push(tween);
            }
        }
        this._tweens = tmp;
    };
    return Timeline;
}());
module.exports = Timeline;

},{"./Tween":4}],4:[function(require,module,exports){
"use strict";
var Easing = require("./Easing");
var ActionType = require("./ActionType");
/**
 * オブジェクトの状態を変化させるアクションを定義するクラス。
 * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
 */
var Tween = /** @class */ (function () {
    /**
     * Tweenを生成する。
     * @param target 対象となるオブジェクト
     * @param option オプション
     */
    function Tween(target, option) {
        this._target = target;
        this._stepIndex = 0;
        this._loop = !!option && !!option.loop;
        this._modifiedHandler = option && option.modified ? option.modified : undefined;
        this._destroyedHandler = option && option.destroyed ? option.destroyed : undefined;
        this._steps = [];
        this._lastStep = undefined;
        this._pararel = false;
        this.paused = false;
    }
    /**
     * オブジェクトの状態を変化させるアクションを追加する。
     * @param props 変化内容
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.to = function (props, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * オブジェクトの状態を変化させるアクションを追加する。
     * 変化内容はアクション開始時を基準とした相対値で指定する。
     * @param props 変化内容
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
     */
    Tween.prototype.by = function (props, duration, easing, multiply) {
        if (easing === void 0) { easing = Easing.linear; }
        if (multiply === void 0) { multiply = false; }
        var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
        var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
     * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
     */
    Tween.prototype.con = function () {
        this._pararel = true;
        return this;
    };
    /**
     * オブジェクトの変化を停止するアクションを追加する。
     * @param duration 停止する時間（ミリ秒）
     */
    Tween.prototype.wait = function (duration) {
        var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * 関数を即座に実行するアクションを追加する。
     * @param func 実行する関数
     */
    Tween.prototype.call = function (func) {
        var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * 一時停止するアクションを追加する。
     * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
     */
    Tween.prototype.pause = function () {
        var _this = this;
        return this.call(function () {
            _this.paused = true;
        });
    };
    /**
     * 待機時間をキーとして実行したい関数を複数指定する。
     * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
     */
    Tween.prototype.cue = function (funcs) {
        var keys = Object.keys(funcs);
        keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
        });
        var q = [];
        for (var i = 0; i < keys.length; ++i) {
            q.push({ time: Number(keys[i]), func: funcs[keys[i]] });
        }
        var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
     * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.every = function (func, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
        };
        this._push(action);
        return this;
    };
    /**
     * ターゲットをフェードインさせるアクションを追加する。
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.fadeIn = function (duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ opacity: 1 }, duration, easing);
    };
    /**
     * ターゲットをフェードアウトさせるアクションを追加する。
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.fadeOut = function (duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ opacity: 0 }, duration, easing);
    };
    /**
     * ターゲットを指定した座標に移動するアクションを追加する。
     * @param x x座標
     * @param y y座標
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.moveTo = function (x, y, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ x: x, y: y }, duration, easing);
    };
    /**
     * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
     * @param x x座標
     * @param y y座標
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.moveBy = function (x, y, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.by({ x: x, y: y }, duration, easing);
    };
    /**
     * ターゲットのX座標を指定した座標に移動するアクションを追加する。
     * @param x x座標
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.moveX = function (x, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ x: x }, duration, easing);
    };
    /**
     * ターゲットのY座標を指定した座標に移動するアクションを追加する。
     * @param y y座標
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.moveY = function (y, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ y: y }, duration, easing);
    };
    /**
     * ターゲットを指定した角度に回転するアクションを追加する。
     * @param angle 角度
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.rotateTo = function (angle, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ angle: angle }, duration, easing);
    };
    /**
     * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
     * @param angle 角度
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.rotateBy = function (angle, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.by({ angle: angle }, duration, easing);
    };
    /**
     * ターゲットを指定した倍率に拡縮するアクションを追加する。
     * @param scaleX X方向の倍率
     * @param scaleY Y方向の倍率
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.to({ scaleX: scaleX, scaleY: scaleY }, duration, easing);
    };
    /**
     * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
     * @param scaleX X方向の倍率
     * @param scaleY Y方向の倍率
     * @param duration 変化に要する時間（ミリ秒）
     * @param easing Easing関数（指定しない場合は`Easing.linear`）
     */
    Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
        if (easing === void 0) { easing = Easing.linear; }
        return this.by({ scaleX: scaleX, scaleY: scaleY }, duration, easing, true);
    };
    /**
     * Tweenが破棄されたかどうかを返す。
     * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
     */
    Tween.prototype.destroyed = function () {
        var ret = false;
        if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
        }
        if (!ret) {
            ret = this._stepIndex >= this._steps.length && !this._loop;
        }
        return ret;
    };
    /**
     * アニメーションを実行する。
     * @param delta 前フレームからの経過時間
     */
    Tween.prototype._fire = function (delta) {
        if (this._steps.length === 0 || this.destroyed() || this.paused) {
            return;
        }
        if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
                this._stepIndex = 0;
            }
            else {
                return;
            }
        }
        var actions = this._steps[this._stepIndex];
        var remained = false;
        for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];
            if (!action.initialized) {
                this._initAction(action);
            }
            if (action.finished) {
                continue;
            }
            action.elapsed += delta;
            switch (action.type) {
                case ActionType.Call:
                    action.func.call(this._target);
                    break;
                case ActionType.Every:
                    var progress = action.easing(action.elapsed, 0, 1, action.duration);
                    if (progress > 1) {
                        progress = 1;
                    }
                    action.func.call(this._target, action.elapsed, progress);
                    break;
                case ActionType.TweenTo:
                case ActionType.TweenBy:
                case ActionType.TweenByMult:
                    var keys = Object.keys(action.goal);
                    for (var j = 0; j < keys.length; ++j) {
                        var key = keys[j];
                        if (action.elapsed >= action.duration) {
                            this._target[key] = action.goal[key];
                        }
                        else {
                            this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                        }
                    }
                    break;
                case ActionType.Cue:
                    var cueAction = action.cue[action.cueIndex];
                    if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                        cueAction.func.call(this._target);
                        ++action.cueIndex;
                    }
                    break;
            }
            if (this._modifiedHandler) {
                this._modifiedHandler.call(this._target);
            }
            if (action.elapsed >= action.duration) {
                action.finished = true;
            }
            else {
                remained = true;
            }
        }
        if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
                actions[k].initialized = false;
            }
            ++this._stepIndex;
        }
    };
    /**
     * Tweenの実行状態をシリアライズして返す。
     */
    Tween.prototype.serializeState = function () {
        var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
        };
        for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];
            for (var j = 0; j < this._steps[i].length; ++j) {
                tData._steps[i][j] = {
                    input: this._steps[i][j].input,
                    start: this._steps[i][j].start,
                    goal: this._steps[i][j].goal,
                    duration: this._steps[i][j].duration,
                    elapsed: this._steps[i][j].elapsed,
                    type: this._steps[i][j].type,
                    cueIndex: this._steps[i][j].cueIndex,
                    initialized: this._steps[i][j].initialized,
                    finished: this._steps[i][j].finished
                };
            }
        }
        return tData;
    };
    /**
     * Tweenの実行状態を復元する。
     * @param serializedstate 復元に使う情報。
     */
    Tween.prototype.deserializeState = function (serializedState) {
        this._stepIndex = serializedState._stepIndex;
        for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
                if (!serializedState._steps[i][j] || !this._steps[i][j])
                    continue;
                this._steps[i][j].input = serializedState._steps[i][j].input;
                this._steps[i][j].start = serializedState._steps[i][j].start;
                this._steps[i][j].goal = serializedState._steps[i][j].goal;
                this._steps[i][j].duration = serializedState._steps[i][j].duration;
                this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
                this._steps[i][j].type = serializedState._steps[i][j].type;
                this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
                this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
                this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
        }
    };
    /**
     * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
     * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
     */
    Tween.prototype._push = function (action) {
        if (this._pararel) {
            this._lastStep.push(action);
        }
        else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
        }
        this._pararel = false;
    };
    Tween.prototype._initAction = function (action) {
        action.elapsed = 0;
        action.start = {};
        action.goal = {};
        action.cueIndex = 0;
        action.finished = false;
        action.initialized = true;
        if (action.type !== ActionType.TweenTo
            && action.type !== ActionType.TweenBy
            && action.type !== ActionType.TweenByMult) {
            return;
        }
        var keys = Object.keys(action.input);
        for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];
            if (this._target[key] !== undefined) {
                action.start[key] = this._target[key];
                if (action.type === ActionType.TweenTo) {
                    action.goal[key] = action.input[key];
                }
                else if (action.type === ActionType.TweenBy) {
                    action.goal[key] = action.start[key] + action.input[key];
                }
                else if (action.type === ActionType.TweenByMult) {
                    action.goal[key] = action.start[key] * action.input[key];
                }
            }
        }
    };
    return Tween;
}());
module.exports = Tween;

},{"./ActionType":1,"./Easing":2}],5:[function(require,module,exports){
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Timeline = require("./Timeline");
exports.Tween = require("./Tween");
exports.Easing = require("./Easing");

},{"./Easing":2,"./Timeline":3,"./Tween":4}],6:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Button = /** @class */ (function (_super) {
    __extends(Button, _super);
    function Button(scene, s, x, y, w, h) {
        if (x === void 0) { x = 0; }
        if (y === void 0) { y = 0; }
        if (w === void 0) { w = 100; }
        if (h === void 0) { h = 50; }
        var _this = _super.call(this, {
            scene: scene,
            cssColor: "white",
            width: w,
            height: h,
            x: x,
            y: y,
            touchable: true
        }) || this;
        _this.num = 0;
        _this.chkEnable = function (ev) { return true; };
        _this.pushEvent = function () { };
        if (Button.font == null) {
            Button.font = new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.Monospace,
                size: 32
            });
        }
        _this.label = new g.Label({
            scene: scene,
            font: Button.font,
            text: s[0],
            fontSize: 24,
            textColor: "black",
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            width: w
        });
        _this.label.y = (h - _this.label.height) / 2;
        _this.label.modified();
        _this.append(_this.label);
        _this.pointDown.add(function (ev) {
            if (!_this.chkEnable(ev))
                return;
            _this.cssColor = "gray";
            _this.modified();
            if (s.length !== 1) {
                _this.num = (_this.num + 1) % s.length;
                _this.label.text = s[_this.num];
                _this.label.invalidate();
            }
        });
        _this.pointUp.add(function (ev) {
            _this.cssColor = "white";
            _this.modified();
            _this.pushEvent(ev);
        });
        return _this;
    }
    return Button;
}(g.FilledRect));
exports.Button = Button;

},{}],7:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
//魚クラス
var Fish = /** @class */ (function (_super) {
    __extends(Fish, _super);
    function Fish(scene) {
        var _this = _super.call(this, { scene: scene }) || this;
        _this.muki = 1;
        _this.speed = 3;
        _this.score = 100;
        _this.flg = false;
        _this.num = 0;
        var anchor = new g.E({ scene: scene });
        _this.append(anchor);
        var sprImages = [];
        var assetNames = ["fish", "fish2", "ika", "ebi", "kani", "kurage",
            "ningyo", "pengin", "kame", "maguro",
            "same", "iruka", "king", "tako", "siva", "hebi", "robo"];
        for (var i = 0; i < assetNames.length; i++) {
            var image = scene.assets[assetNames[i]];
            sprImages.push(new g.FrameSprite({
                scene: scene,
                src: image,
                width: image.width,
                height: image.height / 2,
                frames: [0, 1],
                interval: 200
            }));
        }
        _this.sprImage = sprImages[0];
        anchor.append(_this.sprImage);
        _this.collisionArea = new g.FilledRect({ scene: scene, width: 40, height: 40, cssColor: "#ff000020" });
        _this.append(_this.collisionArea);
        _this.collisionArea.hide();
        var cntLoop = g.game.random.get(0, 30);
        var cntTest = 0;
        _this.update.add(function (ev) {
            if (!_this.flg) {
                if (_this.muki === 1 && _this.x > g.game.width + (_this.sprImage.width / 2)) {
                    if (g.game.random.get(0, 100) <= Fish.escapes[_this.num]) {
                        _this.reset();
                    }
                    turn();
                }
                else if (_this.muki === -1 && _this.x < -(_this.sprImage.width / 2)) {
                    if (g.game.random.get(0, 100) <= Fish.escapes[_this.num]) {
                        _this.reset();
                    }
                    turn();
                }
                _this.x += (_this.speed * _this.muki);
                //エビ・イカ(途中でターンする、たまに早く動く)
                if (_this.num === 2 || _this.num === 3) {
                    if ((cntLoop % 20) === 0) {
                        cntTest++;
                        if ((cntTest % 5) === 0) {
                            _this.speed = 12;
                            if (_this.num === 3 && _this.muki === -1) {
                                _this.speed = 17;
                            }
                        }
                        else {
                            if (_this.num === 3 && g.game.random.get(0, 2) === 0) {
                                turn();
                            }
                            _this.speed = g.game.random.get(2, 12) / 2;
                        }
                    }
                }
                //マグロ、サメ(たまに早く動く)
                if (_this.num === 9 || _this.num === 10) {
                    if ((cntLoop % 20) === 0) {
                        cntTest++;
                        if ((cntTest % 5) === 0) {
                            _this.speed = 15;
                        }
                        else {
                            _this.speed = g.game.random.get(2, 12) / 2;
                        }
                    }
                }
                //人魚、ペンギン、亀(途中でターンする)
                if (_this.num === 6 || _this.num === 7 || _this.num === 8) {
                    if ((cntLoop % 20) === 0) {
                        if (g.game.random.get(0, 50) === 0) {
                            turn();
                        }
                    }
                }
                //クラゲ(上下にも動く)
                if (_this.num === 5) {
                    if (cntTest === 1 && _this.y > g.game.height - 50) {
                        cntTest = -1;
                    }
                    else if (cntTest === -1 && _this.y < 150) {
                        cntTest = 1;
                    }
                    _this.y += cntTest;
                }
            }
            _this.modified();
            cntLoop++;
        });
        var turn = function () {
            _this.muki *= -1;
            if (_this.num !== 4) {
                anchor.scaleX *= -1; //カニ以外の表示反転
            }
        };
        _this.hit = function (num) {
            _this.flg = true;
            _this.x = -_this.muki * 20 + 40;
            _this.y = 20 * (5 - num);
            anchor.angle = (45 + g.game.random.get(0, 20)) * -_this.muki;
            _this.modified();
        };
        _this.reset = function () {
            if (_this.sprImage.parent !== undefined) {
                anchor.remove(_this.sprImage);
            }
            _this.num = Fish.nums[Fish.numsCnt];
            Fish.numsCnt = (Fish.numsCnt + 1) % 100;
            _this.sprImage = sprImages[_this.num];
            anchor.append(_this.sprImage);
            _this.flg = false;
            _this.muki = -1;
            _this.score = Fish.scores[_this.num] * 100;
            if (_this.num === 5) {
                _this.speed = 2; //クラゲ
            }
            else {
                _this.speed = g.game.random.get(6, 15) / 2;
            }
            _this.x = g.game.width + _this.sprImage.width - _this.sprImage.x;
            if (_this.num !== 4) {
                _this.y = g.game.random.get(120, g.game.height);
            }
            else {
                _this.y = g.game.random.get(g.game.height - 50, g.game.height); //カニだけ下のほうにしか表示されない
            }
            anchor.scaleX = 1;
            anchor.angle = 0;
            if (_this.num === 5) {
                //クラゲ
                _this.sprImage.x = -(_this.sprImage.width / 2);
                _this.sprImage.y = -(_this.sprImage.height / 2);
                _this.collisionArea.x = -5;
                _this.collisionArea.y = -5;
                _this.collisionArea.width = 10;
                _this.collisionArea.height = 10;
            }
            else {
                _this.sprImage.x = -(_this.sprImage.width / 3);
                _this.sprImage.y = -(_this.sprImage.height / 2);
                _this.collisionArea.x = -(_this.sprImage.width / 3);
                _this.collisionArea.y = -(_this.sprImage.height / 2);
                _this.collisionArea.width = _this.sprImage.width / 1.5;
                _this.collisionArea.height = _this.sprImage.height;
            }
            cntTest = 1;
            _this.sprImage.start();
        };
        return _this;
    }
    Fish.nums = new Array(100);
    Fish.numsCnt = 0;
    Fish.scores = [8, 10, 12, 13, 14, 0, 100, 30, 40, 50, 120, 120, 200, 150, 170, 180, 190];
    Fish.escapes = [1, 1, 1, 1, 1, 50, 10, 10, 10, 50, 50, 80, 80, 80, 80, 80, 80];
    return Fish;
}(g.E));
exports.Fish = Fish;

},{}],8:[function(require,module,exports){
"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Button_1 = require("./Button");
var Fish_1 = require("./Fish");
var MainScene = /** @class */ (function (_super) {
    __extends(MainScene, _super);
    function MainScene(param) {
        var _this = this;
        param.assetIds =
            ["title", "time", "pt", "start", "finish", "warning", "tairyou", "tairyou2", "hari",
                "fish", "fish2", "ebi", "ika", "kani", "kurage",
                "ningyo", "pengin", "kame", "maguro",
                "same", "iruka", "king", "tako", "siva", "hebi", "robo",
                "kuma", "line", "img_numbers_n", "img_numbers_n_red", "test", "name", "hand",
                "bgm", "biri", "move", "clear", "miss", "se_start", "se_timeup"];
        _this = _super.call(this, param) || this;
        var tl = require("@akashic-extension/akashic-timeline");
        var timeline = new tl.Timeline(_this);
        _this.loaded.add(function () {
            var score = 0;
            var hitCnt = 0;
            var isStart = false;
            _this.assets["bgm"].play().changeVolume(0.2);
            g.game.vars.gameState = { score: 0 };
            // 何も送られてこない時は、標準の乱数生成器を使う
            var random = g.game.random;
            _this.message.add(function (msg) {
                if (msg.data && msg.data.type === "start" && msg.data.parameters) {
                    var sessionParameters = msg.data.parameters;
                    if (sessionParameters.randomSeed != null) {
                        // プレイヤー間で共通の乱数生成器を生成
                        // `g.XorshiftRandomGenerator` は Akashic Engine の提供する乱数生成器実装で、 `g.game.random` と同じ型。
                        random = new g.XorshiftRandomGenerator(sessionParameters.randomSeed);
                    }
                }
            });
            // 配信者のIDを取得
            _this.lastJoinedPlayerId = "";
            g.game.join.add(function (ev) {
                _this.lastJoinedPlayerId = ev.player.id;
            });
            // 背景
            var bg = new g.FilledRect({ scene: _this, width: 0, height: 0, cssColor: "#000000" });
            _this.append(bg);
            bg.touchable = true;
            bg.hide();
            if (typeof window !== "undefined" && window.RPGAtsumaru) {
                bg.width = 640;
                bg.height = 360;
                bg.cssColor = "#aaccff";
                bg.modified();
            }
            _this.font = new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.Monospace,
                size: 15
            });
            // タイトル
            var sprTitle = new g.Sprite({ scene: _this, src: _this.assets["title"], x: 70 });
            _this.append(sprTitle);
            timeline.create(sprTitle, {
                modified: sprTitle.modified, destroyd: sprTitle.destroyed
            }).wait(5000).moveBy(-800, 0, 200).call(function () {
                bg.show();
                uiBase.show();
                isStart = true;
                reset();
            });
            var glyph = JSON.parse(_this.assets["test"].data);
            var numFont = new g.BitmapFont({
                src: _this.assets["img_numbers_n"],
                map: glyph.map,
                defaultGlyphWidth: glyph.width,
                defaultGlyphHeight: glyph.height,
                missingGlyph: glyph.missingGlyph
            });
            var numFontRed = new g.BitmapFont({
                src: _this.assets["img_numbers_n_red"],
                map: glyph.map,
                defaultGlyphWidth: glyph.width,
                defaultGlyphHeight: glyph.height,
                missingGlyph: glyph.missingGlyph
            });
            var font = new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.Monospace,
                size: 24
            });
            var uiBase = new g.E({ scene: _this });
            _this.append(uiBase);
            uiBase.hide();
            var fg = new g.FilledRect({ scene: _this, width: 640, height: 480, cssColor: "#ff0000", opacity: 0.0 });
            _this.append(fg);
            //スコア
            var labelScore = new g.Label({
                scene: _this, font: numFont, fontSize: 32, text: "0P", x: 100, y: 5,
                width: 350, textAlign: g.TextAlign.Right, widthAutoAdjust: false
            });
            uiBase.append(labelScore);
            //何匹釣れたか
            var cntHitAll = 0;
            var labelNum = new g.Label({
                scene: _this, font: numFont, fontSize: 32, text: "0Q", x: 400, y: 35,
                width: 100, textAlign: g.TextAlign.Right, widthAutoAdjust: false
            });
            uiBase.append(labelNum);
            //連れた魚の詳細表示用
            var sprFishStates = [];
            var sprFishNames = [];
            var labelFishCnts = [];
            var labelFishScores = [];
            for (var i = 0; i < 5; i++) {
                var base = new g.E({
                    scene: _this, x: 450,
                    y: 65 + (60 * i)
                });
                uiBase.append(base);
                base.hide();
                sprFishStates.push(base);
                var spr = new g.FrameSprite({
                    scene: _this,
                    src: _this.assets["name"],
                    width: 150,
                    height: 30,
                    frames: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
                });
                base.append(spr);
                sprFishNames.push(spr);
                var label = new g.Label({
                    scene: _this, font: numFont, fontSize: 25, text: "*2", x: 0, y: 3,
                    width: 190, textAlign: g.TextAlign.Right, widthAutoAdjust: false
                });
                base.append(label);
                labelFishCnts.push(label);
                var label2 = new g.Label({
                    scene: _this, font: numFont, fontSize: 28, text: "+100000", x: 0, y: 30,
                    width: 190, textAlign: g.TextAlign.Right, widthAutoAdjust: false
                });
                base.append(label2);
                labelFishScores.push(label2);
            }
            //組み合わせボーナス表示
            var sprHandStates = [];
            var labelHandScores = [];
            var sprHandNames = [];
            for (var i = 0; i < 2; i++) {
                var base = new g.E({
                    scene: _this, x: 250,
                    y: 245 + (60 * (1 - i))
                });
                uiBase.append(base);
                base.hide();
                sprHandStates.push(base);
                var spr = new g.FrameSprite({
                    scene: _this,
                    src: _this.assets["hand"],
                    width: 150,
                    height: 30,
                    frames: [0, 1, 2, 3, 4, 5]
                });
                base.append(spr);
                sprHandNames.push(spr);
                var label = new g.Label({
                    scene: _this, font: numFont, fontSize: 28, text: "+100000", x: 0, y: 30,
                    width: 190, textAlign: g.TextAlign.Right, widthAutoAdjust: false
                });
                base.append(label);
                labelHandScores.push(label);
            }
            //タイム
            uiBase.append(new g.Sprite({ scene: _this, src: _this.assets["time"], x: 540, y: 2 }));
            var labelTime = new g.Label({ scene: _this, font: numFont, fontSize: 32, text: "70", x: 580, y: 5 });
            uiBase.append(labelTime);
            //加点分
            var labelPlus = new g.Label({ scene: _this, font: numFontRed, fontSize: 32, text: "0", x: 250, y: 60 });
            uiBase.append(labelPlus);
            //スタート
            var sprStart = new g.Sprite({ scene: _this, src: _this.assets["start"], x: 70, y: 100 });
            uiBase.append(sprStart);
            //終了
            var sprFinish = new g.Sprite({ scene: _this, src: _this.assets["finish"], x: 120, y: 100 });
            uiBase.append(sprFinish);
            //大漁
            var sprTairyou = new g.Sprite({ scene: _this, src: _this.assets["tairyou"], x: 120, y: 100 });
            uiBase.append(sprTairyou);
            //大量ボーナス用
            var sprTairyou2 = new g.FrameSprite({ scene: _this, src: _this.assets["tairyou2"], width: 280, height: 40, frames: [0, 1], x: 160, y: 250 });
            uiBase.append(sprTairyou2);
            //魚群注意
            var sprWarning = new g.Sprite({ scene: _this, src: _this.assets["warning"], x: 50, y: 100 });
            uiBase.append(sprWarning);
            //リセットボタン
            var btnReset = new Button_1.Button(_this, ["リセット"], 520, 300);
            if (typeof window !== "undefined" && window.RPGAtsumaru) {
                uiBase.append(btnReset);
            }
            btnReset.pushEvent = function (ev) { return reset(); };
            //くま
            var sprKuma = new g.FrameSprite({
                scene: _this,
                src: _this.assets["kuma"],
                width: 100,
                height: 200,
                frames: [0, 1, 2],
                x: 50,
                y: -20
            });
            bg.append(sprKuma);
            //水面
            var sprLine = new g.FrameSprite({
                scene: _this,
                src: _this.assets["line"],
                width: 640,
                height: 20,
                frames: [0, 1],
                interval: 500,
                y: 120
            });
            sprLine.start();
            bg.append(sprLine);
            //針
            var hariCnt = 2;
            var sprHari = new g.E({
                scene: _this,
                width: 80,
                height: 130,
                x: 135,
                y: g.game.height - 130,
            });
            bg.append(sprHari);
            //糸
            sprHari.append(new g.FilledRect({
                scene: _this,
                width: 1,
                height: 350,
                cssColor: "black",
                x: 39,
                y: -243
            }));
            sprHari.append(new g.FilledRect({
                scene: _this,
                width: 1,
                height: 350,
                cssColor: "white",
                x: 40,
                y: -243,
                opacity: 0.5
            }));
            var sprHaris = [];
            for (var i = 0; i < 5; i++) {
                var spr = new g.Sprite({
                    scene: _this,
                    src: _this.assets["hari"],
                    x: 10,
                    y: 100 - (i * 25)
                });
                if (i % 2)
                    spr.scaleX = -1;
                spr.modified();
                sprHaris.push(spr);
                sprHari.append(spr);
            }
            //sprHari.children = [];
            var hariState = 0;
            _this.pointDownCapture.add(function () {
                if (!isStart)
                    return;
                if (sprFinish.state === 0 /* None */)
                    return;
                if (hariState === 3)
                    hariState = 1;
            });
            //魚
            var sprFishs = [];
            for (var i = 0; i < 6; i++) {
                var sprFish = new Fish_1.Fish(_this);
                bg.append(sprFish);
                sprFishs.push(sprFish);
            }
            //メインループ
            var frameCnt = 0;
            var startTime = 0;
            var tweens = [];
            var handBonus = [3000, 8000, 20000, 5000, 15000, 50000];
            var rareTime = 12; //大物が出現する時間
            var bkTime = 0;
            var timeLimit = 70;
            _this.update.add(function () {
                if (!isStart)
                    return;
                if (hariState === 1) {
                    if (sprHari.y < -80) {
                        hariState = 2;
                        var num_1 = 0;
                        cntHitAll += hitCnt;
                        labelNum.text = "" + cntHitAll + "Q";
                        labelNum.invalidate();
                        //釣れた魚をカウント
                        var kurageFlg_1 = false;
                        sprFishs.forEach(function (e) {
                            if (kurageFlg_1)
                                return;
                            if (e.flg) {
                                if (e.num === 5) {
                                    kurageFlg_1 = true;
                                    num_1 = 0;
                                    return;
                                }
                                num_1 += e.score;
                            }
                        });
                        //釣った魚の情報表示用
                        var hash_1 = {};
                        var singleFlg_1 = true; //１匹ずつしか釣れていない
                        var maxHit_1 = 0; //同種最大
                        sprFishs.forEach(function (e) {
                            if (e.flg) {
                                if (hash_1[e.num]) {
                                    hash_1[e.num]++;
                                    singleFlg_1 = false;
                                    if (maxHit_1 < hash_1[e.num])
                                        maxHit_1 = hash_1[e.num];
                                }
                                else {
                                    hash_1[e.num] = 1;
                                }
                            }
                        });
                        sprFishStates.forEach(function (e) { return e.hide(); });
                        var cnt = 0;
                        tweens.forEach(function (e) {
                            timeline.remove(e);
                        });
                        tweens.length = 0;
                        var _loop_1 = function (i) {
                            if (hash_1[i]) {
                                var s_1 = sprFishStates[cnt];
                                s_1.show();
                                tweens.push(timeline.create().wait(3000).call(function () { return s_1.hide(); }));
                                sprFishNames[cnt].frameNumber = i;
                                sprFishNames[cnt].modified();
                                labelFishCnts[cnt].text = (hash_1[i] > 1) ? "*" + hash_1[i] : "";
                                labelFishCnts[cnt].invalidate();
                                if (!kurageFlg_1) {
                                    labelFishScores[cnt].text = "+" + (Fish_1.Fish.scores[i] * hash_1[i] * 100);
                                }
                                else {
                                    labelFishScores[cnt].text = "+0";
                                }
                                labelFishScores[cnt].invalidate();
                                cnt++;
                            }
                        };
                        for (var i = 0; i < 17; i++) {
                            _loop_1(i);
                        }
                        //組み合わせボーナスの表示
                        sprHandStates[0].hide();
                        if (!kurageFlg_1) {
                            var i = -1;
                            if (singleFlg_1 && hitCnt >= 3) {
                                i = hitCnt - 3;
                            }
                            else if (maxHit_1 >= 3) {
                                i = maxHit_1;
                            }
                            if (i !== -1) {
                                sprHandNames[0].frameNumber = i;
                                labelHandScores[0].text = "+" + handBonus[i];
                                labelHandScores[0].invalidate();
                                sprHandNames[0].modified();
                                sprHandStates[0].show();
                                tweens.push(timeline.create().wait(3000).call(function () { return sprHandStates[0].hide(); }));
                                num_1 += handBonus[i];
                            }
                        }
                        //大量
                        if (!kurageFlg_1 && hitCnt >= hariCnt) {
                            if (hariCnt < 5) {
                                sprHaris[hariCnt].show();
                                sprTairyou2.frameNumber = 0;
                                hariCnt++;
                            }
                            else {
                                sprTairyou2.frameNumber = 1;
                                num_1 += 10000;
                            }
                            sprTairyou.show();
                            timeline.create(sprTairyou, {
                                modified: sprTairyou.modified, destroyd: sprTairyou.destroyed
                            }).wait(1000).call(function () { return sprTairyou.hide(); });
                            sprTairyou2.modified();
                            timeline.create(sprTairyou2, {
                                modified: sprTairyou2.modified, destroyd: sprTairyou2.destroyed
                            }).wait(200).call(function () { return sprTairyou2.show(); }).wait(800).call(function () { return sprTairyou2.hide(); });
                        }
                        sprKuma.frameNumber = kurageFlg_1 ? 2 : 1;
                        sprKuma.modified();
                        sprHari.angle = -30;
                        sprHari.modified();
                        if (kurageFlg_1) {
                            _this.assets["biri"].play().changeVolume(0.3);
                        }
                        else if (hitCnt !== 0) {
                            _this.assets["clear"].play().changeVolume(0.3);
                        }
                        else {
                            _this.assets["miss"].play().changeVolume(0.3);
                        }
                        addScore(num_1);
                        hitCnt = 0;
                        timeline.create(sprKuma, {
                            modified: sprKuma.modified, destroyd: sprKuma.destroyed
                        }).wait(500).call(function () {
                            //釣ったあとの処理
                            sprKuma.frameNumber = 0;
                            hariState = 0;
                            sprHari.angle = 0;
                            sprHari.modified();
                            //釣れた魚をカウントしてリリース
                            sprFishs.forEach(function (e) {
                                if (e.flg) {
                                    bg.append(e);
                                    e.reset();
                                }
                            });
                        });
                    }
                    sprHari.y -= 10;
                    sprFishs.forEach(function (e) {
                        //針との当たり判定
                        if (hariCnt > hitCnt) {
                            if (!e.flg && collision(e.collisionArea, sprHari, bg)) {
                                e.hit(hitCnt);
                                sprHari.append(e);
                                hitCnt++;
                                _this.assets["move"].play().changeVolume(0.3);
                            }
                        }
                    });
                }
                else if (hariState === 0) {
                    if (sprHari.y <= g.game.height - sprHari.height)
                        sprHari.y += 10;
                    else
                        hariState = 3;
                }
                var t = timeLimit - Math.floor((Date.now() - startTime) / 1000);
                var t2 = ((timeLimit + 2) - Math.floor(frameCnt / 30)); //フレームレート改竄バグによるチート行為対応
                if (t <= -1 || t2 === 0) {
                    labelTime.text = "0";
                    labelTime.invalidate();
                    if (sprFinish.state === 1 /* Hidden */) {
                        sprFinish.show();
                        _this.assets["se_timeup"].play().changeVolume(0.8);
                        timeline.create().wait(3000).call(function () {
                            if (typeof window !== "undefined" && window.RPGAtsumaru) {
                                window.RPGAtsumaru.experimental.scoreboards.setRecord(1, g.game.vars.gameState.score).then(function () {
                                    window.RPGAtsumaru.experimental.scoreboards.display(1);
                                    btnReset.show();
                                });
                            }
                        });
                    }
                    fg.cssColor = "#000000";
                    fg.opacity = 0.1;
                    fg.modified();
                }
                else if (t >= 0) {
                    labelTime.text = "" + t;
                    labelTime.invalidate();
                    if (t === rareTime && Fish_1.Fish.numsCnt < 50) {
                        Fish_1.Fish.numsCnt = 50;
                    }
                    if (bkTime !== t && t <= 5) {
                        fg.opacity = 0.1;
                        fg.modified();
                        timeline.create().wait(500).call(function () {
                            fg.opacity = 0.0;
                            fg.modified();
                        });
                    }
                    bkTime = t;
                    frameCnt++;
                }
            });
            //スコアの追加処理
            var addScore = function (num) {
                labelPlus.text = "+" + num;
                labelPlus.invalidate();
                labelPlus.show();
                timeline.create(labelPlus, {
                    modified: labelPlus.modified, destroyd: labelPlus.destroyed
                }).wait(2000).call(function () { return labelPlus.hide(); });
                timeline.create(labelScore, {
                    modified: labelScore.modified, destroyd: labelScore.destroyed
                }).every(function (e, p) {
                    labelScore.text = "" + (score + Math.floor(num * p)) + "P";
                    labelScore.invalidate();
                }, 500).call(function () {
                    score += num;
                    g.game.vars.gameState.score = score;
                });
            };
            //リセット
            var reset = function () {
                sprStart.show();
                sprFinish.hide();
                sprTairyou.hide();
                sprTairyou2.hide();
                sprWarning.hide();
                labelPlus.hide();
                btnReset.hide();
                hariCnt = 2;
                fg.cssColor = "#ff0000";
                fg.opacity = 0.0;
                fg.modified();
                for (var i = hariCnt; i < 5; i++) {
                    sprHaris[i].hide();
                }
                timeline.create(sprStart, {
                    modified: sprStart.modified, destroyd: sprStart.destroyed
                }).wait(2000).call(function () { return sprStart.hide(); });
                for (var i = 0; i < 20; i++) {
                    if ((i % 10) === 5) {
                        Fish_1.Fish.nums[i] = 5;
                    }
                    else {
                        Fish_1.Fish.nums[i] = random.get(0, 4);
                    }
                }
                for (var i = 20; i < 50; i++) {
                    Fish_1.Fish.nums[i] = random.get(0, 11);
                }
                for (var i = 50; i < 100; i++) {
                    Fish_1.Fish.nums[i] = random.get(6, 16);
                }
                Fish_1.Fish.numsCnt = 0;
                sprFishs.forEach(function (e) { return e.reset(); });
                score = 0;
                labelScore.text = "0P";
                labelScore.invalidate();
                labelTime.text = "70";
                labelTime.invalidate();
                cntHitAll = 0;
                labelNum.text = "0Q";
                labelNum.invalidate();
                isStart = true;
                _this.assets["se_start"].play().changeVolume(0.8);
                startTime = Date.now();
                frameCnt = 0;
            };
            //シンプルな当たり判定。
            //親子関係のみ考慮(拡大、回転があると動かない,シーンには未対応)
            var collision = function (e1, e2, baseE) {
                var x1 = e1.x;
                var y1 = e1.y;
                var e = e1;
                while (true) {
                    if (baseE === e || e.parent === undefined)
                        break;
                    e = e.parent;
                    x1 += e.x;
                    y1 += e.y;
                }
                var w1 = x1 + e1.width;
                var h1 = y1 + e1.height;
                var x2 = e2.x;
                var y2 = e2.y;
                e = e2;
                while (true) {
                    if (baseE === e || e.parent === undefined)
                        break;
                    e = e.parent;
                    x2 += e.x;
                    y2 += e.y;
                }
                var w2 = x2 + e2.width;
                var h2 = y2 + e2.height;
                return (x2 < w1 && x1 < w2 && y2 < h1 && y1 < h2);
            };
        });
        return _this;
    }
    return MainScene;
}(g.Scene));
exports.MainScene = MainScene;

},{"./Button":6,"./Fish":7,"@akashic-extension/akashic-timeline":5}],9:[function(require,module,exports){
"use strict";
var MainScene_1 = require("./MainScene");
function main(param) {
    //const DEBUG_MODE: boolean = true;
    var scene = new MainScene_1.MainScene({ game: g.game });
    g.game.pushScene(scene);
}
module.exports = main;

},{"./MainScene":8}]},{},[9])(9)
});
